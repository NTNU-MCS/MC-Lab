import time
import serial

ser = serial.Serial('/dev/ttyAMA0',115200)
print ser.portstr

ser.write("Helloworld")

ser.close()
