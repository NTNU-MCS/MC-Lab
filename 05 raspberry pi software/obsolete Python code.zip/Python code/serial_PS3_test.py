#!/usr/bin/env python

import pygame
import time
import math
import serial


pygame.init()
j = pygame.joystick.Joystick(0)
j.init()

print 'Initialized Joystick : %s' % j.get_name()


ser = serial.Serial('/dev/ttyAMA0',115200)
print ser.portstr

try:
    command = (0,0,0)
    lighton = False
    lc = 0
    while True:
        pygame.event.pump()
        left_x_aks = j.get_axis(0)
        left_y_aks = j.get_axis(1)
        right_x_aks = j.get_axis(2)
        right_y_aks = j.get_axis(3)
        #four = j.get_axis(4)
        #five = j.get_axis(5)
        #six = j.get_axis(6)
        #seven = j.get_axis(7)
        arrow_up = j.get_axis(8)
        arrow_rigth = j.get_axis(9)
        arrow_down = j.get_axis(10)
        arrow_left = j.get_axis(11) #not working
        L2 = j.get_axis(12)
        R2 = j.get_axis(13)
        L1 = j.get_axis(14)
        R1 = j.get_axis(15)
        triangle = j.get_axis(16)
        circle = j.get_axis(17)
        cross = j.get_axis(18)
        square = j.get_axis(19)
        #twenty = j.get_axis(20)
        #print "NR8: %f  NR9: %f NR10: %f NR11: %f NR12: %f  NR13: %f NR14: %f NR15: %f NR16: %f NR17: %f  NR18: %f NR19: %f NR20: %f" % (eight,nine,ten,eleven,twelve,thirteen,fourteen,fifteen,sixteen,seventeen,eighteen,nineteen,twenty)

        l_angle = math.atan2(left_x_aks,left_y_aks)*180/math.pi
        r_angle = math.atan2(right_x_aks,right_y_aks)*180/math.pi
        print "left angle = %f    right angle = %f" % (l_angle,r_angle)
        ser.write("left angle = %f    right angle = %f" % (l_angle,r_angle))
        if(circle != -1):
            break
except KeyboardInterrupt:
    j.quit()

ser.close()
